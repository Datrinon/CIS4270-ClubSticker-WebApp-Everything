<?php require('views/clubStickerHeader.php'); ?>
<main>
	<section class="error-diagnostic">
		<h1 class="page-subtitle"> Goodbye </h1>
		<p style='text-align:center; font-size:115%'>You have been logged out successfully. See you next time!</p>
			<button onclick="document.location='.'"> Return Home </button>

	</section>
</main>
<main id='Content'>
</main>
<?php require('views/clubStickerFooter.php');

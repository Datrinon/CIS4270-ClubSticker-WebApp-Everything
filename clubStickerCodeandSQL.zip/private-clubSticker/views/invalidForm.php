<?php require('views/clubStickerHeader.php'); ?>
<main>
    <section class="error-diagnostic">
        <h1 id="error-diagnostic-title" style="text-align:center;">Invalid or expired form!</h1>
        <!-- <p style='text-align:center; font-size:115%'> Please avoid reloading the browser on forms. </p> -->
        <button onclick="document.location='.'"> Go home </button>
    </section>
</main>
<?php require('views/clubStickerFooter.php');

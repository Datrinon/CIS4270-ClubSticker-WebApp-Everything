<?php require('views/clubStickerHeader.php'); ?>
<main>
    <section class="error-diagnostic">
        <h1 class="page-subtitle" style="line-height: 1.3;"> Please login to view this page.</h1>
        <p style='text-align:center; font-size:125%'> Press OK to continue. </p>
        <button onclick="document.location='?ctlr=user&amp;action=login'"> OK! </button>
    </section>
</main>
<?php require('views/clubStickerFooter.php'); ?>
<?php

/**
 * Password generator utility
 * 
 * @author jam
 * @version 171223
 */
include_once('includes/rercAppIncludes.php');

// Set this variable to the password you want.
$pw = 'password';
// var_dump(password_hash($pw, PASSWORD_DEFAULT));

